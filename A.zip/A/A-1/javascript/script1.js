// JavaScript Document
jQuery(document).ready(function(){
	
	//submenu
	$(".navi").mouseover(function(){
		$(this).find(".submenu").stop().slideDown();
	}).mouseout(function(){
		$(this).find(".submenu").stop().slideUp();
	});
	
	//위에서 아래로 이미지 슬라이드
	var imgs = 2;
	var now = 0;
	
	start();
	
	function start(){
		$(".imgslide > a").eq(0).siblings().animate({marginTop:"-500px"});
		
		setInterval(function(){
			now = now == imgs ? 0 : now += 1;
			$(".imgslide > a").eq(now - 1).animate({marginTop:"-500px"});
			$(".imgslide > a").eq(now).animate({marginTop:"0px"});
		}, 3000);}
	
	//탭메뉴 공지사항-갤러리
	$(function(){
		$(".tabmenu > li > a").click(function(){
			$(this).parent().addClass("active").siblings().removeClass("active");
			return false;
		});
	});
	
	//팝업창 구현
	$(".notice li:first-child").click(function(){
		$("#modal").addClass("active");
	});
	$(".btn").click(function(){
		$("#modal").removeClass("active");
	});
	
});