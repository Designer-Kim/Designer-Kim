jQuery(document).ready(function(){

  $(".navi").mouseover(function(){
    $(this).find(".submenu").stop().slideDown(500);
  }).mouseout(function(){
    $(this).find(".submenu").stop().slideUp(500);
  });

  var imgs = 2;
  var now = 0;

  start();

  function start(){
    $(".imgslide > a:first-child").siblings().animate({"marginTop":"-300px"});
    setInterval(function(){
      now = now == imgs ? 0 : now += 1;
      $(".imgslide > a").eq(now - 1).animate({"marginTop":"-300px"});
      $(".imgslide > a").eq(now).animate({"marginTop":"0px"});
    }, 3000)
  };

  $(function(){
    $(".tabmenu > li > a").click(function(){
      $(this).parent().addClass("active").siblings().removeClass("active");
      return false;
    });
  });

  $(".notice li:first-child").click(function(){
    $("#modal").addClass("active");
  });
  $(".btn").click(function(){
    $("#modal").removeClass("active");
  })

});