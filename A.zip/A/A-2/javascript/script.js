// JavaScript Document
jQuery(document).ready(function(){
	
	$(".navi").mouseover(function(){
		$(this).find(".submenu").stop().slideDown(500);
		$("#menuwrap").stop().animate({
			"height":"220px"
		});
	}).mouseout(function(){
		$(this).find(".submenu").stop().slideUp(500);
		$("#menuwrap").stop().animate({
			"height":"100px"
		});
	});
	
	/*var imgs = 2;
    var now = 0;

    start();

    function start(){
		$(".imgslide > a").eq(0).siblings().animate({left: "-1200px"});

		setInterval(function(){
			now = now == imgs ? 0 : now += 1;
			$(".imgslide > a").eq(now - 1).animate({left: "-1200px"});
			$(".imgslide > a").eq(now).animate({left: "1200px"});}, 3000); }*/
	
	/*var currentIndex = 0;
	
	setInterval(function(){
        if (currentIndex < 2){
            currentIndex++;
        }
        else {
            currentIndex = 0;
        }
        var slidePosition = currentIndex * (-1200) + "px";
        $(".imgslide > a").animate({left : slidePosition}, 1200);
    },3000);*/
	
	var imgs = 2;
	var now = 0;

	start(); 
	
	function start(){
		$(".imgslide > a").eq(0).siblings().css({"margin-left":"-2000px"});
		setInterval(function(){slide();},3000);
	}
	
	function slide(){
		now = now == imgs ? 0 : now += 1;
		$(".imgslide > a").eq(now - 1).css({"margin-left":"-2000px"});   
		$(".imgslide > a").eq(now).css({"margin-left":"0px"});
	}
	
	$(".notice li:first").click(function(){
		$("#modal").addClass("active");
	});
	$(".btn").click(function(){
		$("#modal").removeClass("active");
	});
	
});