// JavaScript Document
jQuery(document).ready(function(){
	$(".navi > li").mouseover(function(){
		$(".submenu").stop().slideDown();	
	}).mouseout(function(){
		$(".submenu").stop().slideUp();
	});
	
	/*$(".navi").mouseover(function(){
		$(this).find(".submenu").stop().slideDown(500);
	}).mouseout(function(){
		$(this).find(".submenu").stop().slideUp(500);
	});*/
	
	// imgs와 now 변수 생성 후 start()함수를 만든다.
	// start함수의 첫 부분은 eq(0).siblings().animate()를 쓰는데, setInterval() 함수 후에는 siblings()를 쓰지않는다.
	// eq(now-1)이 eq(now)보다 먼저다.
	var imgs = 2;
	var now = 0;
	
	start();
	
	function start(){
		$(".imgslide > a").eq(0).siblings().animate({"marginLeft":"-1600px"});
		
		setInterval(function(){
			now = now == imgs ? 0 : now += 1;
		$(".imgslide > a").eq(now - 1).animate({"marginLeft":"-1600px"});
		$(".imgslide > a").eq(now).animate({"marginLeft":"0"});
	}, 3000);}
	
	$(function(){
		$(".tabmenu > li > a").click(function(){
			$(this).parent().addClass("active").siblings().removeClass("active");
			return false;
		});
	});
	
	$(".notice li:first").click(function(){
		$("#modal").addClass("active");
	});
	$(".btn").click(function(){
		$("#modal").removeClass("active");
	});
	
});