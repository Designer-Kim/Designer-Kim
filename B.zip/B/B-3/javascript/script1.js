// JavaScript Document
jQuery(document).ready(function(){
	
	$(".navi > li").mouseover(function(){
		$(this).find(".submenu").stop().slideDown();
	}).mouseout(function(){
		$(this).find(".submenu").stop().slideUp();
	});
	
	var imgs = 2;
	var now = 0;
	
	start();
	
	function start(){
		$(".imgslide > a").eq(0).siblings().animate({"marginTop": "-300px"});
		
		setInterval(function(){
			now = now == imgs ? 0 : now += 1;
			$(".imgslide > a").eq(now - 1).animate({"marginTop": "-300px"});
			$(".imgslide > a").eq(now).animate({"marginTop": "0"});
		}, 3000);
	}
	
	$(".notice li:first-child").click(function(){
		$("#modal").addClass("active");
	});
	$(".btn").click(function(){
		$("#modal").removeClass("active");
	})
	
});