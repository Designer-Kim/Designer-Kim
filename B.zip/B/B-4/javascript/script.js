// JavaScript Document
jQuery(document).ready(function(){
	
	$(".navi > li").mouseover(function(){	//내가 찾아낸 메뉴 슬라이드(1200px) 구현 방법
		$(".menuwrap").stop().slideDown(500);
		$(".submenu").stop().slideDown(500);
	}).mouseout(function(){
		$(".menuwrap").stop().slideUp(500);
		$(".submenu").stop().slideUp(500);
	});
	
	var imgs = 2;
    var now = 0;

    start();

    function start(){
      $(".imgslide > a").eq(0).siblings().animate({marginLeft:"-1800px"});

      setInterval(function(){
        now = now == imgs ? 0 : now += 1;
        $(".imgslide > a").eq(now - 1).animate({marginLeft:"-1800px"});
        $(".imgslide > a").eq(now).animate({marginLeft:"0"});
      }, 3000);}
	
});