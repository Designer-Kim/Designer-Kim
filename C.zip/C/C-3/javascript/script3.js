jQuery(document).ready(function(){

  $(".navi > li").mouseover(function(){
    $(this).find(".submenu1").stop().slideDown();
    $(this).find(".submenu2").stop().slideDown();
    $(this).find(".submenu3").stop().slideDown();
    $(this).find(".submenu4").stop().slideDown();
  }).mouseout(function(){
    $(this).find(".submenu1").stop().slideUp();
    $(this).find(".submenu2").stop().slideUp();
    $(this).find(".submenu3").stop().slideUp();
    $(this).find(".submenu4").stop().slideUp();
  });

  var imgs = 2;
  var now = 0;

  start();

  function start(){
    $(".imgslide a:first-child").siblings().animate({"marginLeft":"-800px"});
    setInterval(function(){
      now = now == imgs ? 0 : now += 1;
      $(".imgslide > a").eq(now - 1).animate({"marginLeft":"-800px"});
      $(".imgslide > a").eq(now).animate({"marginLeft":"0px"});
    }, 3000);
  }

  $(".notice li:first-child").click(function(){
		$("#modal").addClass("active");
	});
	$(".btn").click(function(){
		$("#modal").removeClass("active");
	});

});