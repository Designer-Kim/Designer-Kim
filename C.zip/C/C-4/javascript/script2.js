jQuery(document).ready(function(){
  
  $(".navi > li").mouseover(function(){
    $(this).find(".submenu").stop().slideDown();
  }).mouseout(function(){
    $(this).find(".submenu").stop().slideUp();
  });

  var imgs = 2;
  var now = 0;
  start();
  function start(){
    $(".imgslide a:first-child").siblings().animate({"marginLeft":"-800px"});
    setInterval(function(){
      now = now == imgs ? 0 : now += 1;
      $(".imgslide > a").eq(now - 1).animate({"marginLeft":"-800px"});
      $(".imgslide > a").eq(now).animate({"marginLeft":"0px"});
    }, 3000);
  }

  $(".notice li:first-child").click(function(){
    $("#modal").addClass("active");
  });
  $(".btn").click(function(){
    $("#modal").removeClass("active");
  });

});